-- MariaDB dump 10.19-11.0.1-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: mobidb
-- ------------------------------------------------------
-- Server version	11.0.1-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrador` (
  `idAdmin` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `idSede` varchar(10) NOT NULL,
  PRIMARY KEY (`idAdmin`),
  KEY `idUsuario` (`idUsuario`),
  KEY `idSede` (`idSede`),
  CONSTRAINT `administrador_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`),
  CONSTRAINT `administrador_ibfk_2` FOREIGN KEY (`idSede`) REFERENCES `sede` (`idSede`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `idArea` varchar(10) NOT NULL,
  `idSede` varchar(10) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idArea`),
  KEY `idSede` (`idSede`),
  CONSTRAINT `area_ibfk_1` FOREIGN KEY (`idSede`) REFERENCES `sede` (`idSede`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bicicleta`
--

DROP TABLE IF EXISTS `bicicleta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bicicleta` (
  `idBicicleta` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `idTipoRodada` varchar(10) NOT NULL,
  PRIMARY KEY (`idBicicleta`),
  KEY `vhCode` (`vhCode`),
  KEY `idTipoRodada` (`idTipoRodada`),
  CONSTRAINT `bicicleta_ibfk_1` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`),
  CONSTRAINT `bicicleta_ibfk_2` FOREIGN KEY (`idTipoRodada`) REFERENCES `tipo_rodada` (`idTipoRodada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bicicleta`
--

LOCK TABLES `bicicleta` WRITE;
/*!40000 ALTER TABLE `bicicleta` DISABLE KEYS */;
/*!40000 ALTER TABLE `bicicleta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estacionamiento`
--

DROP TABLE IF EXISTS `estacionamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estacionamiento` (
  `idMovimiento` varchar(10) NOT NULL,
  `idAsignacion` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `fechaIngreso` datetime NOT NULL,
  PRIMARY KEY (`idMovimiento`),
  KEY `idAsignacion` (`idAsignacion`),
  KEY `idUsuario` (`idUsuario`),
  KEY `vhCode` (`vhCode`),
  CONSTRAINT `estacionamiento_ibfk_1` FOREIGN KEY (`idMovimiento`) REFERENCES `movimiento` (`idMovimiento`),
  CONSTRAINT `estacionamiento_ibfk_2` FOREIGN KEY (`idAsignacion`) REFERENCES `vigilante_puerta` (`idAsignacion`),
  CONSTRAINT `estacionamiento_ibfk_3` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`),
  CONSTRAINT `estacionamiento_ibfk_4` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estacionamiento`
--

LOCK TABLES `estacionamiento` WRITE;
/*!40000 ALTER TABLE `estacionamiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `estacionamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidente`
--

DROP TABLE IF EXISTS `incidente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidente` (
  `idIncidente` varchar(10) NOT NULL,
  `idVigilante` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `idArea` varchar(10) NOT NULL,
  `idTipoIncidente` varchar(10) NOT NULL,
  `fechaRegistro` datetime NOT NULL,
  `detalles` varchar(300) NOT NULL,
  `foto` varchar(100) NOT NULL,
  PRIMARY KEY (`idIncidente`),
  KEY `idVigilante` (`idVigilante`),
  KEY `vhCode` (`vhCode`),
  KEY `idArea` (`idArea`),
  KEY `idTipoIncidente` (`idTipoIncidente`),
  CONSTRAINT `incidente_ibfk_1` FOREIGN KEY (`idVigilante`) REFERENCES `vigilante` (`idVigilante`),
  CONSTRAINT `incidente_ibfk_2` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`),
  CONSTRAINT `incidente_ibfk_3` FOREIGN KEY (`idArea`) REFERENCES `area` (`idArea`),
  CONSTRAINT `incidente_ibfk_4` FOREIGN KEY (`idTipoIncidente`) REFERENCES `tipo_incidente` (`idTipoIncidente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidente`
--

LOCK TABLES `incidente` WRITE;
/*!40000 ALTER TABLE `incidente` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miembro`
--

DROP TABLE IF EXISTS `miembro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miembro` (
  `matricula` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `idArea` varchar(10) NOT NULL,
  `idTipoMiembro` varchar(10) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `teléfono` varchar(10) NOT NULL,
  `mail` varchar(70) NOT NULL,
  `verificado` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`matricula`),
  KEY `idUsuario` (`idUsuario`),
  KEY `idArea` (`idArea`),
  KEY `idTipoMiembro` (`idTipoMiembro`),
  CONSTRAINT `miembro_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`),
  CONSTRAINT `miembro_ibfk_2` FOREIGN KEY (`idArea`) REFERENCES `area` (`idArea`),
  CONSTRAINT `miembro_ibfk_3` FOREIGN KEY (`idTipoMiembro`) REFERENCES `tipo_miembro` (`idTipoMiembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miembro`
--

LOCK TABLES `miembro` WRITE;
/*!40000 ALTER TABLE `miembro` DISABLE KEYS */;
/*!40000 ALTER TABLE `miembro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `motocicleta`
--

DROP TABLE IF EXISTS `motocicleta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `motocicleta` (
  `idMotocicleta` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `idTipoEstilo` varchar(10) NOT NULL,
  PRIMARY KEY (`idMotocicleta`),
  KEY `vhCode` (`vhCode`),
  KEY `idTipoEstilo` (`idTipoEstilo`),
  CONSTRAINT `motocicleta_ibfk_1` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`),
  CONSTRAINT `motocicleta_ibfk_2` FOREIGN KEY (`idTipoEstilo`) REFERENCES `tipo_estilo` (`idTipoEstilo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `motocicleta`
--

LOCK TABLES `motocicleta` WRITE;
/*!40000 ALTER TABLE `motocicleta` DISABLE KEYS */;
/*!40000 ALTER TABLE `motocicleta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento`
--

DROP TABLE IF EXISTS `movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimiento` (
  `idMovimiento` varchar(10) NOT NULL,
  `idAsignacion` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `esFlag` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idMovimiento`),
  KEY `idAsignacion` (`idAsignacion`),
  KEY `idUsuario` (`idUsuario`),
  KEY `vhCode` (`vhCode`),
  CONSTRAINT `movimiento_ibfk_1` FOREIGN KEY (`idAsignacion`) REFERENCES `vigilante_puerta` (`idAsignacion`),
  CONSTRAINT `movimiento_ibfk_2` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`),
  CONSTRAINT `movimiento_ibfk_3` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento`
--

LOCK TABLES `movimiento` WRITE;
/*!40000 ALTER TABLE `movimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamo`
--

DROP TABLE IF EXISTS `prestamo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamo` (
  `idPrestamo` varchar(10) NOT NULL,
  `matricula` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `mtrPrestatario` varchar(10) NOT NULL,
  `fechaInicio` datetime NOT NULL,
  `fechaFin` datetime NOT NULL,
  `activeFlag` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idPrestamo`),
  KEY `matricula` (`matricula`),
  KEY `vhCode` (`vhCode`),
  KEY `mtrPrestatario` (`mtrPrestatario`),
  CONSTRAINT `prestamo_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `miembro` (`matricula`),
  CONSTRAINT `prestamo_ibfk_2` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`),
  CONSTRAINT `prestamo_ibfk_3` FOREIGN KEY (`mtrPrestatario`) REFERENCES `miembro` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamo`
--

LOCK TABLES `prestamo` WRITE;
/*!40000 ALTER TABLE `prestamo` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestamo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puerta`
--

DROP TABLE IF EXISTS `puerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puerta` (
  `idPuerta` varchar(10) NOT NULL,
  `idSede` varchar(10) DEFAULT NULL,
  `idTipoPuerta` varchar(10) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idPuerta`),
  KEY `idSede` (`idSede`),
  KEY `idTipoPuerta` (`idTipoPuerta`),
  CONSTRAINT `puerta_ibfk_1` FOREIGN KEY (`idSede`) REFERENCES `sede` (`idSede`),
  CONSTRAINT `puerta_ibfk_2` FOREIGN KEY (`idTipoPuerta`) REFERENCES `tipo_puerta` (`idTipoPuerta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puerta`
--

LOCK TABLES `puerta` WRITE;
/*!40000 ALTER TABLE `puerta` DISABLE KEYS */;
/*!40000 ALTER TABLE `puerta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scooter`
--

DROP TABLE IF EXISTS `scooter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scooter` (
  `idScooter` varchar(10) NOT NULL,
  `vhCode` varchar(10) NOT NULL,
  `idTipoMotor` varchar(10) NOT NULL,
  PRIMARY KEY (`idScooter`),
  KEY `vhCode` (`vhCode`),
  KEY `idTipoMotor` (`idTipoMotor`),
  CONSTRAINT `scooter_ibfk_1` FOREIGN KEY (`vhCode`) REFERENCES `vehiculo` (`vhCode`),
  CONSTRAINT `scooter_ibfk_2` FOREIGN KEY (`idTipoMotor`) REFERENCES `tipo_motor` (`idTipoMotor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scooter`
--

LOCK TABLES `scooter` WRITE;
/*!40000 ALTER TABLE `scooter` DISABLE KEYS */;
/*!40000 ALTER TABLE `scooter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sede`
--

DROP TABLE IF EXISTS `sede`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sede` (
  `idSede` varchar(7) NOT NULL,
  `nombre` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`idSede`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sede`
--

LOCK TABLES `sede` WRITE;
/*!40000 ALTER TABLE `sede` DISABLE KEYS */;
/*!40000 ALTER TABLE `sede` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_estilo`
--

DROP TABLE IF EXISTS `tipo_estilo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_estilo` (
  `idTipoEstilo` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoEstilo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_estilo`
--

LOCK TABLES `tipo_estilo` WRITE;
/*!40000 ALTER TABLE `tipo_estilo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_estilo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_incidente`
--

DROP TABLE IF EXISTS `tipo_incidente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_incidente` (
  `idTipoIncidente` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoIncidente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_incidente`
--

LOCK TABLES `tipo_incidente` WRITE;
/*!40000 ALTER TABLE `tipo_incidente` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_incidente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_miembro`
--

DROP TABLE IF EXISTS `tipo_miembro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_miembro` (
  `idTipoMiembro` varchar(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`idTipoMiembro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_miembro`
--

LOCK TABLES `tipo_miembro` WRITE;
/*!40000 ALTER TABLE `tipo_miembro` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_miembro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_motivo`
--

DROP TABLE IF EXISTS `tipo_motivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_motivo` (
  `idTipoMotivo` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoMotivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_motivo`
--

LOCK TABLES `tipo_motivo` WRITE;
/*!40000 ALTER TABLE `tipo_motivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_motivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_motor`
--

DROP TABLE IF EXISTS `tipo_motor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_motor` (
  `idTipoMotor` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoMotor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_motor`
--

LOCK TABLES `tipo_motor` WRITE;
/*!40000 ALTER TABLE `tipo_motor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_motor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_puerta`
--

DROP TABLE IF EXISTS `tipo_puerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_puerta` (
  `idTipoPuerta` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoPuerta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_puerta`
--

LOCK TABLES `tipo_puerta` WRITE;
/*!40000 ALTER TABLE `tipo_puerta` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_puerta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_rodada`
--

DROP TABLE IF EXISTS `tipo_rodada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_rodada` (
  `idTipoRodada` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTipoRodada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_rodada`
--

LOCK TABLES `tipo_rodada` WRITE;
/*!40000 ALTER TABLE `tipo_rodada` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_rodada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `idUsuario` varchar(10) NOT NULL,
  `userType` enum('Administrador','Miembro','Visitante','Vigilante') NOT NULL,
  `usuario` varchar(25) DEFAULT NULL,
  `contraseña` varchar(80) DEFAULT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellidoP` varchar(30) NOT NULL,
  `apellidoM` varchar(30) NOT NULL,
  `fechaRegistro` datetime NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES
('USR0628982','Administrador','DASU_CU','7fnPkHGGEO595TwNzCUHOSOQRN6boRW7DKYCbD5JWKU=','Juan','Perez','Ramirez','2023-08-17 09:54:05'),
('USR6333397','Miembro',NULL,'XohImNooBHFR0OVvjcYpJ3NgPQ1qq73WKhHvch0VQtg=','José Eduardo','Arrucha','Álvarez','2023-08-17 09:56:28'),
('USR9780039','Vigilante',NULL,'RrIVCszHW0rntGH+T13eOVEtLgNO5Nkd+cCbm9DgkMk=','Juan','Sosa','Ruiz','2023-08-17 10:03:57');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehiculo`
--

DROP TABLE IF EXISTS `vehiculo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehiculo` (
  `vhCode` varchar(10) NOT NULL,
  `idUsuario` varchar(10) DEFAULT NULL,
  `vhType` enum('Bicicleta','Motocicleta','Scooter') DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `marca` varchar(30) NOT NULL,
  `modelo` varchar(20) NOT NULL,
  `color` varchar(20) NOT NULL,
  `fechaRegistro` datetime DEFAULT NULL,
  PRIMARY KEY (`vhCode`),
  KEY `idUsuario` (`idUsuario`),
  CONSTRAINT `vehiculo_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehiculo`
--

LOCK TABLES `vehiculo` WRITE;
/*!40000 ALTER TABLE `vehiculo` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehiculo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vigilante`
--

DROP TABLE IF EXISTS `vigilante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vigilante` (
  `idVigilante` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `inicioTurno` time NOT NULL,
  `finTurno` time NOT NULL,
  PRIMARY KEY (`idVigilante`),
  KEY `idUsuario` (`idUsuario`),
  CONSTRAINT `vigilante_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante`
--

LOCK TABLES `vigilante` WRITE;
/*!40000 ALTER TABLE `vigilante` DISABLE KEYS */;
/*!40000 ALTER TABLE `vigilante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vigilante_puerta`
--

DROP TABLE IF EXISTS `vigilante_puerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vigilante_puerta` (
  `idAsignacion` varchar(10) NOT NULL,
  `idPuerta` varchar(10) DEFAULT NULL,
  `idVigilante` varchar(10) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`idAsignacion`),
  KEY `idPuerta` (`idPuerta`),
  KEY `idVigilante` (`idVigilante`),
  CONSTRAINT `vigilante_puerta_ibfk_1` FOREIGN KEY (`idPuerta`) REFERENCES `puerta` (`idPuerta`),
  CONSTRAINT `vigilante_puerta_ibfk_2` FOREIGN KEY (`idVigilante`) REFERENCES `vigilante` (`idVigilante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante_puerta`
--

LOCK TABLES `vigilante_puerta` WRITE;
/*!40000 ALTER TABLE `vigilante_puerta` DISABLE KEYS */;
/*!40000 ALTER TABLE `vigilante_puerta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitante`
--

DROP TABLE IF EXISTS `visitante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitante` (
  `idVisitante` varchar(10) NOT NULL,
  `idUsuario` varchar(10) NOT NULL,
  `idAsignacion` varchar(10) DEFAULT NULL,
  `idTipoMotivo` varchar(10) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `teléfono` varchar(10) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idVisitante`),
  KEY `idUsuario` (`idUsuario`),
  KEY `idAsignacion` (`idAsignacion`),
  KEY `idTipoMotivo` (`idTipoMotivo`),
  CONSTRAINT `visitante_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`),
  CONSTRAINT `visitante_ibfk_2` FOREIGN KEY (`idAsignacion`) REFERENCES `vigilante_puerta` (`idAsignacion`),
  CONSTRAINT `visitante_ibfk_3` FOREIGN KEY (`idTipoMotivo`) REFERENCES `tipo_motivo` (`idTipoMotivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitante`
--

LOCK TABLES `visitante` WRITE;
/*!40000 ALTER TABLE `visitante` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitante` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-28 11:58:49
